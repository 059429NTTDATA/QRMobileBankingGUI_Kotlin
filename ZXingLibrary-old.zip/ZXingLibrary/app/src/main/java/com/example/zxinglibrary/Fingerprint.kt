package com.example.zxinglibrary

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Fingerprint : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fingerprint)
    }
}